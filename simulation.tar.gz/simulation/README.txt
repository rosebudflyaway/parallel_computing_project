1. first install and use Boost.MPI. there is a documentation under the directory of ./boostmpi

2. change the rigidmake file 
line 1 MCC = mpic++ -I ~/Downloads/boost_1_49_0
line 5 LIBRARY = -Llibdir /usr/lib/libboost_mpi.so /usr/lib/libboost_serialization.so

3. make -f rigidmake

4. mpirun -np 2 ./simulate -F 0.1 -R 0.1 -I 100 -P

   -F 0.1  is the fraction of the spheres that delete from the layers of bodies

   -R 0.1  is the radius of the body
 
   -I 100  is the iteration step


